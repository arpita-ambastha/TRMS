import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { UserService } from './user.service';
import { ɵnormalizeQueryParams } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class LoginuserService implements OnInit {
  username:string='';
private baseurl="http://localhost:8086/login";
  constructor(private httpclient:HttpClient,private userService:UserService) { }
  loginuser(user:UserService):Observable<object>{
    console.log(user);
    this.userService.setUsername(this.username)
    return this.httpclient.post(`${this.baseurl}`,user);
  }
  ngOnInit(): void {


  }
}
