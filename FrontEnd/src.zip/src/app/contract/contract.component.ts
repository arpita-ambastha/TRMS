import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginuserService } from '../loginuser.service';
import { ContractsService } from '../contracts.service';
import { Observable } from 'rxjs';
import { Contract } from '../contract';
import { UserService } from '../user.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-contract',
  templateUrl: './contract.component.html',
  styleUrl: './contract.component.css'
})
export class ContractComponent implements  OnInit{
 // user:User ={} as User;
 // Username=User.username;
 username:string='';
  contractDetails: any[] = [];
    a="";
  contracts:any;
    contractId!:number;
    prismId="";
    offshoreHC="";
    onsiteHC="";
    offsiteHC="";
    onsitePM="";
    onsiteDM="";
    offshorePM="";
    offshoreDM="";
    offshoreDMSap="";
    offshorePMSap!: number;
    contractStartDate!: Date;
    contractEndDate!: Date;
    vendor="";
    sOWName="";
    engagementType="";
    contractType="";
    relationship="";
    costManagement="";
    quality="";
    delivary="";
    resources="";
    region="";
    contractMgr="";
    contactDirector="";
    valueAddedResources="";
    opco="";
    contactAccessNo="";
    additionPMAcessSap="";
    contactAccessYes="";
    clientManager="";
    clientManagerLDAP="";
    clientDir="";
    clientDirLDAP="";
    clientVP="";
    clientVPLDAP="";
    clientSVP="";
    defaultManager: boolean = false;
  null!: Date;
  contractManagerDetails:any;


  addManagerDetail() {
    // Push an empty object representing a new row to the contractManagerDetails array
    this.contractManagerDetails.push({
      clientManager: '',
      clientManagerLDAP: '',
      clientDir: '',
      clientDirLDAP: '',
      clientVP: '',
      clientVPLDAP: '',
      clientSVP: '',
      defaultManager: ''
    });
  }
    refresh(){
    this.contractId=0;
    this.prismId="";
    this.offshoreHC="";
    this.onsiteHC="";
    this.offsiteHC="";
    this.onsitePM="";
    this.onsiteDM="";
    this.offshorePM="";
    this.offshoreDM="";
    this.offshoreDMSap="";
    this.offshorePMSap=0;
    this.contractStartDate=this.null;
    this.contractEndDate=this.null;
    this.vendor="";
    this.sOWName="";
    this.engagementType="";
    this.contractType="";
    this.relationship="";
    this.costManagement="";
    this.quality="";
    this.delivary="";
    this.resources="";
    this.region="";
    this.contractMgr="";
    this.contactDirector="";
    this.valueAddedResources="";
    this.opco="";
    this.contactAccessNo="";
    this.additionPMAcessSap="";
    this.contactAccessYes="";
    this.clientManager="";
    this.clientManagerLDAP="";
    this.clientDir="";
    this.clientDirLDAP="";
    this.clientVP="";
    this.clientVPLDAP="";
    this.clientSVP="";
    this.defaultManager=true;
    } 
  constructor(private router:Router,private contractService:ContractsService){}
  
  ngOnInit(): void{
    this.contractService.getContracts().subscribe((contracts)=>
    {
      this.contracts=contracts;
    });
  }
  downloadExcel(){
    this.contractService.downloadExcel();
  }
saveContract(){
  let body={
    contractId:this.contractId,
    prismId:this.prismId,
    offshoreHC:this.offshoreHC,
    onsiteHC:this.onsiteHC,
    offsiteHC:this.offsiteHC,
    onsitePM:this.onsitePM,
    onsiteDM:this.onsiteDM,
    offshorePM:this.offshorePM,
    offshoreDM:this.offshoreDM,
    offshoreDMSap:this.offshoreDMSap,
    offshorePMSap:this.offshorePMSap,
    contractStartDate:this.contractStartDate,
    contractEndDate:this.contractEndDate,
    vendor:this.vendor,
    sOWName:this.sOWName,
    engagementType:this.engagementType,
    contractType:this.contractType,
    relationship:this.relationship,
    costManagement:this.costManagement,
    quality:this.quality,
    delivary:this.delivary,
    resources:this.resources,
    region:this.region,
    contractMgr:this.contractMgr,
    contactDirector:this.contactDirector,
    valueAddedResources:this.valueAddedResources,
    opco:this.opco,
    contactAccessNo:this.contactAccessNo,
    additionPMAcessSap:this.additionPMAcessSap,
    contactAccessYes:this.contactAccessYes,
    clientManager:this.clientManager,
    clientManagerLDAP:this.clientManagerLDAP,
    clientDir:this.clientDir,
    clientDirLDAP:this.clientDirLDAP,
    clientVP:this.clientVP,
    clientVPLDAP:this.clientVPLDAP,
    clientSVP:this.clientSVP,
    defaultManager:this.defaultManager
  }
  this.contractService.postContract(body).subscribe((data)=>
  {
    this.contractService.getContracts();
    this.router.navigate(['/contract']);
  });
}  
addRow() {
  this.contractDetails.push({
    clientManager:this.clientManager,
    clientManagerLDAP:"",
    clientDir:"",
    clientDirLDAP:"",
    clientVP:"",
    clientVPLDAP:"",
    clientSVP:"",
    defaultManager:""
  });
}
deleteRow(index: number) {
  this.contractDetails.splice(index, 1);
}
editRow(index: number) {
  this.contractDetails.splice(index, 1);
}
showOptions:boolean=false;
toggleOptions(){
  this.showOptions=!this.showOptions;
}

}
