import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VmoComponent } from './vmo.component';

describe('VmoComponent', () => {
  let component: VmoComponent;
  let fixture: ComponentFixture<VmoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VmoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VmoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
