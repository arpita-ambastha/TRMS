import { Component, OnInit } from '@angular/core';
import { VmoService } from '../vmo.service';
import { Router } from '@angular/router';
import { ContractsService } from '../contracts.service';
import { ThisReceiver } from '@angular/compiler';
import { Contract } from '../contract';

@Component({
  selector: 'app-vmo',
  templateUrl: './vmo.component.html',
  styleUrl: './vmo.component.css'
})
export class VmoComponent implements  OnInit{
  selectedIndices:number[]=[];
  
  isSelected(index:number){
    return this.selectedIndices.includes(index);
  }
  review(index:number){
   // selectRowIndex:this.selectRowIndex;
   // this.selectRowIndex=index;
    if(this.isSelected(index)){
      this.selectedIndices.includes(index);
    }else{
      this.selectedIndices.push(index);
    }

  }
  total(contract:any):number{
    return contract.offshoreHC+contract.onsiteHC;
  }
  //selectRowIndex=0;
  resources:any;
  contracts:any;
  index=0;
  opco="";
  clientManager="";
  clientVP="";
  clientSVP="";
  clientDir="";

  fedexId="";
  fedex_IdRequestedDate!:Date;
  releaseRequestedDate!:Date;
  visatype="";
  cardrole="";
  fedexVenderBadge:boolean=false;
  l1certification="";
   l2certification="";
   mphasissecuritytraining="";
  sapId="";
  fedex_idcreationdate!:Date;
  releaseacknowledagedate!:Date;
  location="";
  clientmanager1="";
  bgvinitiation1:boolean=false;
  fedexsecuritytraining1="";
  clearence:boolean=false;
  name="";
  billable="";
  placement="";	
  companyname="";
  systemacess="";
  supplychain:boolean=false;
  hubstack:boolean=false;
  shipping:boolean=false;
  contractId!:number;
  contract:any;
  constructor(private router:Router,private vmoService:VmoService,private contractService:ContractsService){}

  ngOnInit(): void {
    this.contractService.getContracts().subscribe((contracts)=>
      {
        this.contracts=contracts;
      });
      
  }  

    saveVmo(){
      let body={
  fedexId:this.fedexId,
  fedex_IdRequestedDate:this.fedex_IdRequestedDate,
  releaseRequestedDate:this.releaseRequestedDate,
  visatype:this.visatype,
  cardrole:this.cardrole,
  fedexVenderBadge:this.fedexVenderBadge,
  l1certification:this.l1certification,
  l2certification:this.l2certification,
  mphasissecuritytraining:this.mphasissecuritytraining,
  sapId:this.sapId,
  fedex_idcreationdate:this.fedex_idcreationdate,
  releaseacknowledagedate:this.releaseacknowledagedate,
  location:this.location,
  clientmanager1:this.clientmanager1,
  bgvinitiation1:this.bgvinitiation1,
  fedexsecuritytraining1:this.fedexsecuritytraining1,
  clearence:this.clearence,
  name:this.name,
  billable:this.billable,
  placement:this.placement,
  companyname:this.companyname,
  systemacess:this.systemacess,
  supplychain:this.supplychain,
  hubstack:this.hubstack,
  shipping:this.shipping,
  contractId:this.contractId,
  contract:this.contract
      }
      this.vmoService.postVmo(body).subscribe((data)=>
  {
    console.log(data);
    this.router.navigate(['/vmo']);
  });
    }

    downloadVmo(){
      this.vmoService.downloadVmo();
    } 

    VmoDownload(){
      //contractId:this.contractId;
      this.vmoService.VmoDownload(this.contractId).subscribe((fileData:Blob)=>{
        const url=window.URL.createObjectURL(fileData);
        const a=document.createElement('a');
        document.body.appendChild(a);
        a.style.direction='none';
        a.href=url;
        a.download='Vmo_Download_Report_Vmo.xlsx';
        a.click();
        window.URL.revokeObjectURL(url);
      })
    }
}