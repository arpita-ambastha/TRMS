import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { VmoComponent } from './vmo/vmo.component';

@Injectable({
  providedIn: 'root'
})
export class VmoService {
  contractId: any;
  constructor(private httpClient:HttpClient) { }
  baseUrl:string="http://localhost:8086/createvmo";
  Url:string="http://localhost:8086/contracts";

  postVmo(body: {
      fedexId: string; fedex_IdRequestedDate: Date; releaseRequestedDate: Date; visatype: string; cardrole: string; fedexVenderBadge: boolean; l1certification: string; l2certification: string; mphasissecuritytraining: string; sapId: string; fedex_idcreationdate: Date; releaseacknowledagedate: Date;
         location: string; clientmanager1: string; bgvinitiation1: boolean; fedexsecuritytraining1: string; clearence: boolean; name: string; billable: string; placement: string; companyname: string; systemacess: string; supplychain: boolean; hubstack: boolean; shipping: boolean;contractId: Number;contract:any;
    }){
    console.log(body);
    return this.httpClient.post(this.baseUrl,body)
  }

  downloadVmo(){
    this.httpClient.get("http://localhost:8086/vmo/vmoexcel",{
        responseType:'blob'
      }).subscribe((data:Blob)=>{
      const blob=new Blob([data],{type:'application/octet-stream'});
      const url=window.URL.createObjectURL(blob);
      const a=document.createElement('a');
      a.href=url;
      a.download='Download_Report_Vmo.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

    })
  }
  VmoDownload(contractId:number){
    return this.httpClient.get("http://localhost:8086/vmo/contract/vmoexcel/contractId",{responseType:'blob'},);
  }
    getContracts(){
     return this.httpClient.get(this.Url);

    }
    getdisplay(){
      return []
    }

}
