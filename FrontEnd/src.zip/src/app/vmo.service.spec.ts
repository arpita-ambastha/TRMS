import { TestBed } from '@angular/core/testing';

import { VmoService } from './vmo.service';

describe('VmoService', () => {
  let service: VmoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VmoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
