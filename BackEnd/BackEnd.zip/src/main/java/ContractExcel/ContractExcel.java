package ContractExcel;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.trms.entity.Contract;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

public class ContractExcel {

	 private XSSFWorkbook workbook;
	    private XSSFSheet sheet;
	    private List<Contract> listUsers;
	     
	    public ContractExcel(List<Contract> listUsers) {
	        this.listUsers = listUsers;
	        workbook = new XSSFWorkbook();
	    }
	 
	 
	    private void writeHeaderLine() {
	        sheet = workbook.createSheet("Contract");
	         
	        Row row = sheet.createRow(0);
	         
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setBold(true);
	        font.setFontHeight(16);
	        style.setFont(font);
	         
	        createCell(row, 0, "ContractId", style);      
	        createCell(row, 1, "prismId", style);       
	        createCell(row, 2, "offshoreHC", style);    
	        createCell(row, 3, "onsiteHC", style);
	        createCell(row, 4, "offsiteHC", style);
	        createCell(row, 5, "valueAddedResources", style);      
	        createCell(row, 6, "opco", style);       
	        createCell(row, 7, "onsitePM", style);    
	        createCell(row, 8, "onsiteDM", style);
	        createCell(row, 9, "offshorePM", style);
	        createCell(row, 10, "offshoreDM", style);      
	        createCell(row, 11, "offshoreDMSap", style);       
	        createCell(row, 12, "offshorePMSap", style);    
	        createCell(row, 13, "contractStartDate", style);
	        createCell(row, 14, "contractEndDate", style);
	        createCell(row, 15, " vendor", style);      
	        createCell(row, 16, "sOWName", style);       
	        createCell(row, 17, "engagementType", style);    
	        createCell(row, 18, "contractType", style);
	        createCell(row, 19, "relationship", style);
	        createCell(row, 20, "costManagement", style);      
	        createCell(row, 21, "quality", style);       
	        createCell(row, 22, " delivary", style);    
	        createCell(row, 23, "resources", style);
	        createCell(row, 24, "region", style);
	        createCell(row, 25, "contractMgr", style);      
	        createCell(row, 26, "contactDirector", style);    
	        createCell(row, 27, "contactAccessYes", style);      
	        createCell(row, 28, "contactAccessNo", style);       
	        createCell(row, 29, "additionPMAcessSap", style);    
	        createCell(row, 30, "clientManager", style);
	        createCell(row, 31, "clientManagerLDAP", style);
	        createCell(row, 32, " clientDir", style);      
	        createCell(row, 33, "clientDirLDAP", style);    
	        createCell(row, 34, "clientVP", style);      
	        createCell(row, 35, "clientVPLDAP", style);       
	        createCell(row, 36, "clientSVP", style);    
	        createCell(row, 37, "DefaultManager", style);
	    
	         
	    }
	     
	    private void createCell(Row row, int columnCount, Object value, CellStyle style) {
	        sheet.autoSizeColumn(columnCount);
	        Cell cell = row.createCell(columnCount);
	        if (value instanceof Integer) {
	            cell.setCellValue((Integer) value);
	        } else if (value instanceof Boolean) {
	            cell.setCellValue((Boolean) value);
	        }else if(value instanceof String) {
	            cell.setCellValue((String) value);
	        }
	        else if (value instanceof Long) {
	            cell.setCellValue((Long) value);
	        }
	        else if (value instanceof Float){
	            cell.setCellValue((Float) value);
	        }
	        else {
	        	LocalDate val=LocalDate.now();
	        	String formateDate =val.toString();
	        			cell.setCellValue(formateDate);
	        }
	        
	        cell.setCellStyle(style);
	        
	    }
	     
	    private void writeDataLines() {
	        int rowCount = 1;
	 
	        CellStyle style = workbook.createCellStyle();
	        XSSFFont font = workbook.createFont();
	        font.setFontHeight(14);
	        style.setFont(font);
	                 
	        for (Contract contract: listUsers) {
	            Row row = sheet.createRow(rowCount++);
	            int columnCount = 0;
	             
	            createCell(row, columnCount++, contract.getContractId(), style);
	            createCell(row, columnCount++, contract.getPrismId(), style);
	            createCell(row, columnCount++, contract.getOffshoreHC(), style);
	            createCell(row, columnCount++, contract.getOnsiteHC(), style);
	            createCell(row, columnCount++, contract.getOffsiteHC(), style);
	            createCell(row, columnCount++, contract.getValueAddedResources(), style);
	            createCell(row, columnCount++, contract.getOpco().toString(), style);
	            createCell(row, columnCount++, contract.getOnsitePM().toString(), style);
	            createCell(row, columnCount++, contract.getOnsiteDM().toString(), style);
	            createCell(row, columnCount++, contract.getOffshorePM().toString(), style);
	            createCell(row, columnCount++, contract.getOffshoreDM().toString() ,style);
	            createCell(row, columnCount++,contract.getOffshoreDMSap(), style);
	            createCell(row, columnCount++, contract.getOffshorePMSap(), style);
	            createCell(row, columnCount++, contract.getContractStartDate(), style);
	            createCell(row, columnCount++,contract.getContractEndDate(), style);
	            createCell(row, columnCount++,contract.getVendor().toString() ,style);
	            createCell(row, columnCount++, contract.getsOWName().toString(), style);
	            createCell(row, columnCount++, contract.getEngagementType().toString(), style);
	            createCell(row, columnCount++, contract.getContractType().toString(), style);
	            createCell(row, columnCount++, contract.getRelationship().toString(), style);
	            createCell(row, columnCount++, contract.getCostManagement().toString(), style);
	            createCell(row, columnCount++, contract.getQuality().toString(), style);
	            createCell(row, columnCount++, contract.getDelivary().toString(), style);
	            createCell(row, columnCount++, contract.getResources().toString(), style);
	            createCell(row, columnCount++, contract.getRegion().toString(), style);
	            createCell(row, columnCount++, contract.getContractMgr().toString(), style);
	            createCell(row, columnCount++, contract.getContactDirector().toString(), style);
	            createCell(row, columnCount++, contract.getContactAccessYes().toString(), style);
	            createCell(row, columnCount++, contract.getContactAccessNo().toString(), style);
	            createCell(row, columnCount++, contract.getAdditionPMAcessSap().toString(), style);
	            createCell(row, columnCount++, contract.getClientManager().toString(), style);
	            createCell(row, columnCount++, contract.getClientDirLDAP(), style);
	            createCell(row, columnCount++, contract.getClientDir().toString(), style);
	            createCell(row, columnCount++, contract.getClientDirLDAP(), style);
	            createCell(row, columnCount++,contract.getClientVP().toString(), style);
	            createCell(row, columnCount++,contract.getClientVPLDAP(), style);
	            createCell(row, columnCount++, contract.getClientSVP().toString(), style);
	            createCell(row, columnCount++, contract.isDefaultManager(), style);
	         
	            
	             
	        }
	    }
	     
	    public void export(HttpServletResponse response) throws IOException {
	        writeHeaderLine();
	        writeDataLines();
	         
	        ServletOutputStream outputStream = response.getOutputStream();
	        workbook.write(outputStream);
	        workbook.close();
	         
	        outputStream.close();
	         
	    }
}
