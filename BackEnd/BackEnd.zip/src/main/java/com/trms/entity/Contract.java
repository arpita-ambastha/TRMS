package com.trms.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
 
@Entity
@Table(name = "\"newContract\"")
public class Contract {
 
	@Id
	private long contractId;
	
	private long prismId;
	private float offshoreHC;
	private float onsiteHC;
	private float offsiteHC;
	private float valueAddedResources;
	private String opco;
	private String onsitePM;
	private String onsiteDM;
	private String offshorePM;
	private String offshoreDM;
	private long offshoreDMSap;
	private long offshorePMSap;
	private LocalDate contractStartDate;
	private LocalDate contractEndDate;
	private String vendor;
	private String sOWName;
	private String engagementType;
	private String contractType;
	private String relationship;
	private String costManagement;
	private String quality;
	private String delivary;
	private String resources;
	private String region;
	private String contractMgr;
	private String contactDirector;
	private String contactAccessYes;
	private String contactAccessNo;
	private String additionPMAcessSap;
	private String clientManager;
	private long clientManagerLDAP;
	private String clientDir;
	private long clientDirLDAP;
	private String clientVP;
	private long clientVPLDAP;
	private String clientSVP;
	private boolean DefaultManager;
    
	
 
	
	public String getClientManager() {
		return clientManager;
	}
 
	public void setClientManager(String clientManager) {
		this.clientManager = clientManager;
	}
 
	public long getClientManagerLDAP() {
		return clientManagerLDAP;
	}
 
	public void setClientManagerLDAP(long clientManagerLDAP) {
		this.clientManagerLDAP = clientManagerLDAP;
	}
 
	public String getClientDir() {
		return clientDir;
	}
 
	public void setClientDir(String clientDir) {
		this.clientDir = clientDir;
	}
 
	public long getClientDirLDAP() {
		return clientDirLDAP;
	}
 
	public void setClientDirLDAP(long clientDirLDAP) {
		this.clientDirLDAP = clientDirLDAP;
	}
 
	public String getClientVP() {
		return clientVP;
	}
 
	public void setClientVP(String clientVP) {
		this.clientVP = clientVP;
	}
 
	public long getClientVPLDAP() {
		return clientVPLDAP;
	}
 
	public void setClientVPLDAP(long clientVPLDAP) {
		this.clientVPLDAP = clientVPLDAP;
	}
 
	public String getClientSVP() {
		return clientSVP;
	}
 
	public void setClientSVP(String clientSVP) {
		this.clientSVP = clientSVP;
	}
 
	public boolean isDefaultManager() {
		return DefaultManager;
	}
 
	public void setDefaultManager(boolean defaultManager) {
		DefaultManager = defaultManager;
	}
	/*public void Contracts(long contractId,String offshorePM,
			String offshoreDM, LocalDate contractStartDate,LocalDate contractEndDate, String contractMgr, String contactDirector, String clientManager, String clientDir, String clientVP, String clientSVP) {
		ContractId = contractId;
		this.contractStartDate = contractStartDate;
		this.contractEndDate = contractEndDate;
		this.contractMgr = contractMgr;
		this.contactDirector = contactDirector;
		this.clientManager = clientManager;
		this.clientDir = clientDir;
		this.clientVP = clientVP;
		this.clientSVP = clientSVP;
	} */
 
	public Contract(long contractId, long prismId, float offshoreHC, float onsiteHC, float offsiteHC,
			float valueAddedResources, String opco, String onsitePM, String onsiteDM, String offshorePM,
			String offshoreDM, long offshoreDMSap, long offshorePMSap, LocalDate contractStartDate,
			LocalDate contractEndDate, String vendor, String sOWName, String engagementType, String contractType,
			String relationship, String costManagement, String quality, String delivary, String resources,
			String region, String contractMgr, String contactDirector, String contactAccessYes, String contactAccessNo,
			String additionPMAcessSap, String clientManager, long clientManagerLDAP, String clientDir,
			long clientDirLDAP, String clientVP, long clientVPLDAP, String clientSVP, boolean defaultManager) {
		super();
		this.contractId = contractId;
		this.prismId = prismId;
		this.offshoreHC = offshoreHC;
		this.onsiteHC = onsiteHC;
		this.offsiteHC = offsiteHC;
		this.valueAddedResources = valueAddedResources;
		this.opco = opco;
		this.onsitePM = onsitePM;
		this.onsiteDM = onsiteDM;
		this.offshorePM = offshorePM;
		this.offshoreDM = offshoreDM;
		this.offshoreDMSap = offshoreDMSap;
		this.offshorePMSap = offshorePMSap;
		this.contractStartDate = contractStartDate;
		this.contractEndDate = contractEndDate;
		this.vendor = vendor;
		this.sOWName = sOWName;
		this.engagementType = engagementType;
		this.contractType = contractType;
		this.relationship = relationship;
		this.costManagement = costManagement;
		this.quality = quality;
		this.delivary = delivary;
		this.resources = resources;
		this.region = region;
		this.contractMgr = contractMgr;
		this.contactDirector = contactDirector;
		this.contactAccessYes = contactAccessYes;
		this.contactAccessNo = contactAccessNo;
		this.additionPMAcessSap = additionPMAcessSap;
		this.clientManager = clientManager;
		this.clientManagerLDAP = clientManagerLDAP;
		this.clientDir = clientDir;
		this.clientDirLDAP = clientDirLDAP;
		this.clientVP = clientVP;
		this.clientVPLDAP = clientVPLDAP;
		this.clientSVP = clientSVP;
		DefaultManager = defaultManager;
	}
 
	public Contract() {
		super();
	}
 
	public long getContractId() {
		return contractId;
	}
 
	public void setContractId(long contractId) {
		this.contractId = contractId;
	}
 
	public long getPrismId() {
		return prismId;
	}
 
	public void setPrismId(long prismId) {
		this.prismId = prismId;
	}
 
	public float getOffshoreHC() {
		return offshoreHC;
	}
 
	public void setOffshoreHC(float offshoreHC) {
		this.offshoreHC = offshoreHC;
	}
 
	public float getOnsiteHC() {
		return onsiteHC;
	}
 
	public void setOnsiteHC(float onsiteHC) {
		this.onsiteHC = onsiteHC;
	}
 
	public float getOffsiteHC() {
		return offsiteHC;
	}
 
	public void setOffsiteHC(float offsiteHC) {
		this.offsiteHC = offsiteHC;
	}
 
	public float getValueAddedResources() {
		return valueAddedResources;
	}
 
	public void setValueAddedResources(float valueAddedResources) {
		this.valueAddedResources = valueAddedResources;
	}
 
	public String getOpco() {
		return opco;
	}
 
	public void setOpco(String opco) {
		this.opco = opco;
	}
 
	public String getOnsitePM() {
		return onsitePM;
	}
 
	public void setOnsitePM(String onsitePM) {
		this.onsitePM = onsitePM;
	}
 
	public String getOnsiteDM() {
		return onsiteDM;
	}
 
	public void setOnsiteDM(String onsiteDM) {
		this.onsiteDM = onsiteDM;
	}
 
	public String getOffshorePM() {
		return offshorePM;
	}
 
	public void setOffshorePM(String offshorePM) {
		this.offshorePM = offshorePM;
	}
 
	public String getOffshoreDM() {
		return offshoreDM;
	}
 
	public void setOffshoreDM(String offshoreDM) {
		this.offshoreDM = offshoreDM;
	}
 
	public long getOffshoreDMSap() {
		return offshoreDMSap;
	}
 
	public void setOffshoreDMSap(long offshoreDMSap) {
		this.offshoreDMSap = offshoreDMSap;
	}
 
	public long getOffshorePMSap() {
		return offshorePMSap;
	}
 
	public void setOffshorePMSap(long offshorePMSap) {
		this.offshorePMSap = offshorePMSap;
	}
 
	public LocalDate getContractStartDate() {
		return contractStartDate;
	}
 
	public void setContractStartDate(LocalDate contractStartDate) {
		this.contractStartDate = contractStartDate;
	}
 
	public LocalDate getContractEndDate() {
		return contractEndDate;
	}
 
	public void setContractEndDate(LocalDate contractEndDate) {
		this.contractEndDate = contractEndDate;
	}
 
	public String getVendor() {
		return vendor;
	}
 
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
 
	public String getsOWName() {
		return sOWName;
	}
 
	public void setsOWName(String sOWName) {
		this.sOWName = sOWName;
	}
 
	public String getEngagementType() {
		return engagementType;
	}
 
	public void setEngagementType(String engagementType) {
		this.engagementType = engagementType;
	}
 
	public String getContractType() {
		return contractType;
	}
 
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
 
	public String getRelationship() {
		return relationship;
	}
 
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
 
	public String getCostManagement() {
		return costManagement;
	}
 
	public void setCostManagement(String costManagement) {
		this.costManagement = costManagement;
	}
 
	public String getQuality() {
		return quality;
	}
 
	public void setQuality(String quality) {
		this.quality = quality;
	}
 
	public String getDelivary() {
		return delivary;
	}
 
	public void setDelivary(String delivary) {
		this.delivary = delivary;
	}
 
	public String getResources() {
		return resources;
	}
 
	public void setResources(String resources) {
		this.resources = resources;
	}
 
	public String getRegion() {
		return region;
	}
 
	public void setRegion(String region) {
		this.region = region;
	}
 
	public String getContractMgr() {
		return contractMgr;
	}
 
	public void setContractMgr(String contractMgr) {
		this.contractMgr = contractMgr;
	}
 
	public String getContactDirector() {
		return contactDirector;
	}
 
	public void setContactDirector(String contactDirector) {
		this.contactDirector = contactDirector;
	}
 
	public String getContactAccessYes() {
		return contactAccessYes;
	}
 
	public void setContactAccessYes(String contactAccessYes) {
		this.contactAccessYes = contactAccessYes;
	}
 
	public String getContactAccessNo() {
		return contactAccessNo;
	}
 
	public void setContactAccessNo(String contactAccessNo) {
		this.contactAccessNo = contactAccessNo;
	}
 
	public String getAdditionPMAcessSap() {
		return additionPMAcessSap;
	}
 
	public void setAdditionPMAcessSap(String additionPMAcessSap) {
		this.additionPMAcessSap = additionPMAcessSap;
	}
}