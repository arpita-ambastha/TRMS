package com.trms.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.trms.entity.Contract;
import com.trms.repository.ContractRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;

@Service
public class ContractServiceImpl implements ContractService {
 
	@Autowired
	ContractRepository contractRepo;
 
	@Override
	public List<Contract> findByContractMgr(String contractMgr) {
		
		return contractRepo.findByContractMgr(contractMgr);
	}
	
	@Override
	public Contract newContract(Contract contract) {
		return contractRepo.save(contract);
	}
 
	@Override
	public List<Contract> findByclientVP(String clientVP) {
		return contractRepo.findByclientVP(clientVP);
	}
 
	@Override
	public List<Contract> findByclientSVP(String clientSVP) {
		
		return contractRepo.findByclientSVP(clientSVP);
	}
 
	@Override
	public List<Contract> findByclientDir(String clientDir) {
		
		return contractRepo.findByclientDir(clientDir);
	}
 
	@Override
	public List<Contract> findByoffshorePM(String offshorePM) {
		
		return contractRepo.findByoffshorePM(offshorePM);
	}
 
	@Override
	public List<Contract> findByoffshoreDM(String offshoreDM) {
		
		return contractRepo.findByoffshoreDM(offshoreDM);
	}

	
	@Override
	public Contract findById(Long contract_Id) {
		Contract  id =contractRepo.findById(contract_Id).get();
		return id;	
	}

	@Override
	public Contract updateContract(Contract contract, long id) {
		
		return contractRepo.save(contract);
	}
	@Override
	public List<Contract> getall(){
		return contractRepo.findAll();
		
	}
	@Autowired
	private EntityManager entityManager;
	public List<Contract[]> fetchContract(){
			Query query=entityManager.createQuery("SELECT c.ContractId,c.clientManager,c.clientVP,c.clientSVP,c.clientDir,c.contractMgr,c.offshorePM,c.offshoreDM,c.contractStartDate,c.contractEndDate FROM newContract c");
			return query.getResultList();
			}
	
	
}
 