package com.trms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;
 
import com.trms.entity.VmoEntity;
 
import java.util.List;
 
 
@Repository 
public interface VmoRepository extends JpaRepository<VmoEntity, Long> {
   List<VmoEntity> findByContractContractId(Long contractId);

 
}
